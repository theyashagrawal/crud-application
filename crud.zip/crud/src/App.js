
import React from "react";
import {Routes, Route } from 'react-router-dom';
import Createpost from "./components/Createpost";
import Posts from "./components/Posts";

function App() {
  return (
  <>
  <div >
    <Routes>
      
        <Route path="/" element={<Posts/>}/>
        <Route path="/createpost" element={<Createpost/>}/>
     
    </Routes>
    </div>
 </>
  );
   
       
}

export default App;
